DROP PROCEDURE dbo.spINSERT_dbo_Appointment;
GO

DROP PROCEDURE dbo.spINSERT_dbo_Owner;
GO

DROP PROCEDURE dbo.spINSERT_dbo_Vet;
GO

DROP PROCEDURE dbo.spINSERT_dbo_Pet;
GO

DROP TABLE Appointment;

DROP TABLE Vet;

DROP TABLE Pet;

DROP TABLE Owner;